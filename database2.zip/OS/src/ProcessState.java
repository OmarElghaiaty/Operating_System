public enum ProcessState {
    READY,
    NEW,
    BLOCKED,
    FINISHED,
    RUNNING;
}
